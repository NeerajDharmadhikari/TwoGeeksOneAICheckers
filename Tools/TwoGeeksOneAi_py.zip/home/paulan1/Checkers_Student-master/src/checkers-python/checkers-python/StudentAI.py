from random import randint
from BoardClasses import Move
from BoardClasses import Board
import copy
# The following part should be completed by students.
# Students can modify anything except the class name and existing functions and variables.
# python3 AI_Runner.py 7 7 2 l ../src/checkers-python/main.py Sample_AIs/Random_AI/main.py
# python3 AI_Runner.py 7 7 2 l Sample_AIs/Random_AI/main.py ../src/checkers-python/main.py
MAX, MIN = 1000, -1000
class StudentAI():

    def __init__(self, col, row, p):
        self.col = col
        self.row = row
        self.p = p
        self.board = Board(col, row, p)
        self.board.initialize_game()
        self.color = ''
        self.opponent = {1: 2, 2: 1}
        self.color = 2
        # Returns optimal value for current player  
    
    def get_move(self, move):
        alpha = -1000
        value = -1000
        beta = 1000
        bestMove = None

        if len(move) != 0:  # If the opponent started first
            self.board.make_move(move, self.opponent[self.color])
        else:
            self.color = 1

        # Make a list of all possible moves that our AI can make
        our_moves = self.board.get_all_possible_moves(self.color)

        # Iterate through list of all our moves
        for x in range(len(our_moves)):
            for y in range(len(our_moves[x])):
                # Make a move on the copy/theoretical board
                self.board.make_move(our_moves[x][y], self.color)
                currentScore = self.alphaBetaMin(alpha, beta, 1)
                self.board.undo()
                
                if currentScore >= value:
                    value = currentScore
                    bestMove = our_moves[x][y]
                    alpha = currentScore
        # We assume best move is added
        self.board.make_move(bestMove, self.color)
        return bestMove

    def alphaBetaMin(self, alpha, beta, depth):
        # Check if our AI is black and we won
        if self.color == self.board.is_win(self.color):
            return 1000
        # Check if our AI (black) lost
        elif self.color == 1 and self.board.is_win(self.color) == 2:
            return -1000
        # Check if our AI (white) lost
        elif self.color == 2 and self.board.is_win(self.color) == 1:
            return -1000
        
        # Check if opponent will tie
        if self.board.is_win(self.color) == -1:
            return 0
        if depth == 3:
            return self.get_heuristic_score(self.board)
        else:
            value = 1000
            # Go through every possible move
            opponent_moves = self.board.get_all_possible_moves(self.opponent[self.color])
            for x in opponent_moves:
                for move in x:
                    # Make move for opponent
                    self.board.make_move(move, self.opponent[self.color])
                    value = min(value, self.alphaBetaMax(alpha, beta, depth+1))
                    self.board.undo()
                    beta = min(beta, value)
                    if alpha >= beta:
                        return value
            return value

    def alphaBetaMax(self, alpha, beta, depth):
        # Check if our AI is black and we won
        if self.color == self.board.is_win(self.opponent[self.color]):
            return 1000
        # Check if our AI (black) lost
        elif self.color == 1 and self.board.is_win(self.opponent[self.color]) == 2:
            return -1000
        # Check if our AI (white) lost
        elif self.color == 2 and self.board.is_win(self.opponent[self.color]) == 1:
            return -1000
        
        # Check if opponent will tie
        if self.board.is_win(self.opponent[self.color]) == -1:
            return 0
        if depth == 3:
            return self.get_heuristic_score(self.board)
        else:
            value = -1000
            # Go through every possible move
            our_moves = self.board.get_all_possible_moves(self.color)
            for x in our_moves:
                for move in x:
                    self.board.make_move(move, self.color)
                    value = max(value, self.alphaBetaMin(alpha, beta, depth+1))
                    self.board.undo()
                    alpha = max(alpha, value)
                    if alpha >= beta:
                        return value
            return value

    def get_heuristic_score(self, currentBoard):
        score = 0
        our_king_count = 0
        opp_king_count = 0

        if self.color == 1: # Our color is black
            score = self.board.black_count - self.board.white_count
        else: # our color is white
            score = self.board.white_count - self.board.black_count
        
        for x in range(len(currentBoard.board)):
            for y in range(len(currentBoard.board[x])):
                # Check if it's our checker piece
                if (currentBoard.board[x][y].get_color() == self.color):
                    # Check if it's a king
                    if(currentBoard.board[x][y].is_king == True):
                        our_king_count += 1
                        score += 2
                    else: # Check how close checker piece is to becoming King
                        score += self.closeToBecomingKing(self.color, x)
                    # Check if it's a corner piece either (0, 0), (0, n), (n, 0), or (n, n)
                    cp = currentBoard.board[x][y].get_location()
                    
                    # Check if it's an edge piece row 0, row n, col 0, col n
                    if (cp[0] == 0 or cp[0] == currentBoard.row -1):
                        score += 1
                    if (cp[1] == 0 or cp[1] == currentBoard.col -1):
                        score += 1
                    # If checker piece is not an edge piece
                    if (cp[0] != 0 and cp[0] != currentBoard.row -1):
                        if (cp[1] != 0 and cp[1] != currentBoard.col -1):
                            if(currentBoard.board[x + 1][y - 1].get_color() == self.opponent[self.color]):
                                if(currentBoard.board[x - 1][y + 1].get_color() == '.'):
                                    score -= 3
                            if(currentBoard.board[x + 1][y + 1].get_color() == self.opponent[self.color]):
                                if(currentBoard.board[x - 1][y - 1].get_color() == '.'):
                                    score -= 3
                            if(currentBoard.board[x - 1][y + 1].get_color() == self.opponent[self.color] and currentBoard.board[x - 1][y + 1].is_king):
                                if(currentBoard.board[x + 1][y-1].get_color() == '.'):
                                    score -= 3
                            if(currentBoard.board[x - 1][y - 1].get_color() == self.opponent[self.color] and currentBoard.board[x - 1][y - 1].is_king):
                                if(currentBoard.board[x + 1][y + 1].get_color() == '.'):
                                    score -= 3
                elif(currentBoard.board[x][y].get_color() == self.opponent[self.color]): 
                    if(currentBoard.board[x][y].is_king == True):
                        opp_king_count += 1
                        score -= 2
                    else:
                        score -= self.closeToBecomingKing(self.opponent[self.color], x)
                    # Check if it's a corner piece either (0, 0), (0, n), (n, 0), or (n, n)
                    cp = currentBoard.board[x][y].get_location()
                    
                    # Check if it's an edge piece row 0, row n, col 0, col n
                    if (cp[0] == 0 or cp[0] == currentBoard.row -1):
                        score -= 1
                    if (cp[1] == 0 or cp[1] == currentBoard.col -1):
                        score -= 1
                    
        return score
    
    def closeToBecomingKing(self, color, row_position):
        if self.color == 1: # Our color is black
            return row_position
        else: # our color is white
            return self.board.row - row_position